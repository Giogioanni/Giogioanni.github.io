package tests;
// Giogioanni Morales

import static org.junit.jupiter.api.Assertions.*;

import java.time.Instant;

import org.junit.jupiter.api.Test;

import main.Appointment;
import main.InvalidAppointmentException;

public class AppointmentTest {

    @Test
    public void testValidAppointment() {
        Instant future = Instant.now().plusSeconds(120);
        Appointment appt = new Appointment("A1", future, "Checkup");

        assertEquals("A1", appt.appointmentId());
        assertEquals(future, appt.appointmentDate());
        assertEquals("Checkup", appt.description());
    }

    @Test
    public void testInvalidId() {
        Instant future = Instant.now().plusSeconds(120);

        assertThrows(InvalidAppointmentException.class, () -> new Appointment(null, future, "Valid"));
        assertThrows(InvalidAppointmentException.class, () -> new Appointment("   ", future, "Valid"));
        assertThrows(InvalidAppointmentException.class, () -> new Appointment("12345678910", future, "Valid")); // 11 chars

        // Boundary: exactly 10 is allowed
        assertDoesNotThrow(() -> new Appointment("1234567890", future, "Valid"));
    }

    @Test
    public void testInvalidDate() {
        Instant past = Instant.now().minusSeconds(60);
        Instant future = Instant.now().plusSeconds(120);

        assertThrows(InvalidAppointmentException.class, () -> new Appointment("A1", past, "Valid"));
        assertThrows(InvalidAppointmentException.class, () -> new Appointment("A1", null, "Valid"));

        // Boundary: must be strictly in the future
        assertThrows(InvalidAppointmentException.class, () -> new Appointment("A1", Instant.now(), "Valid"));
        assertDoesNotThrow(() -> new Appointment("A1", future, "Valid"));
    }

    @Test
    public void testInvalidDescription() {
        Instant future = Instant.now().plusSeconds(120);

        assertThrows(InvalidAppointmentException.class, () -> new Appointment("A1", future, null));

        String fiftyOne = "123456789012345678901234567890123456789012345678901"; // 51 chars
        assertThrows(InvalidAppointmentException.class, () -> new Appointment("A1", future, fiftyOne));

        // Boundary: exactly 50 allowed
        String fifty = "12345678901234567890123456789012345678901234567890"; // 50 chars
        assertDoesNotThrow(() -> new Appointment("A1", future, fifty));
    }
}
