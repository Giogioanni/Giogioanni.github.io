package tests;
// Giogioanni Morales

import static org.junit.jupiter.api.Assertions.*;

import java.time.Instant;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import main.Appointment;
import main.AppointmentNotFoundException;
import main.AppointmentService;
import main.DuplicateAppointmentIdException;

public class AppointmentServiceTest {

    private AppointmentService service;

    @BeforeEach // Initialize a fresh service before every test to ensure isolation
    public void setup() {
        service = new AppointmentService();
    }

    @Test
    public void testAddAppointmentAndGet() {
        Instant t1 = Instant.now().plusSeconds(120);
        // Verify that the appointment retrieved matches the one added
        Appointment a = new Appointment("ID1", t1, "Desc");

        service.addAppointment(a);
        assertEquals(a, service.getAppointment("ID1"));
    }

    @Test
    public void testAddDuplicateAppointmentThrows() {
        Instant t1 = Instant.now().plusSeconds(120);
        Appointment a1 = new Appointment("ID1", t1, "Desc1");
        Appointment a2 = new Appointment("ID1", t1.plusSeconds(60), "Desc2");

        service.addAppointment(a1);
        assertThrows(DuplicateAppointmentIdException.class, () -> service.addAppointment(a2));
    }

    @Test
    public void testDeleteAppointment() {
        Instant t1 = Instant.now().plusSeconds(120);
        Appointment a = new Appointment("ID1", t1, "Desc");

        service.addAppointment(a);
        service.deleteAppointment("ID1");

        assertThrows(AppointmentNotFoundException.class, () -> service.getAppointment("ID1"));
    }
    // Test edge cases (DeleteNonexistentAppointment and GetNonexistentAppointment)
    @Test
    public void testDeleteNonexistentAppointmentThrows() {
        assertThrows(AppointmentNotFoundException.class, () -> service.deleteAppointment("MISSING"));
    }

    @Test
    public void testGetNonexistentAppointmentThrows() {
        assertThrows(AppointmentNotFoundException.class, () -> service.getAppointment("MISSING"));
    }

    @Test
    public void testGetNextAppointment() {
        Instant now = Instant.now();
        Instant t1 = now.plusSeconds(120);
        Instant t2 = now.plusSeconds(240);

        service.addAppointment(new Appointment("A", t2, "Later"));
        service.addAppointment(new Appointment("B", t1, "Sooner"));

        Appointment next = service.getNextAppointment(now);
        assertEquals("B", next.appointmentId());
    }

    @Test
    public void testGetNextAppointmentSameTimestampUsesSmallestId() {
        Instant now = Instant.now();
        Instant t = now.plusSeconds(120);

        service.addAppointment(new Appointment("B", t, "Same time B"));
        service.addAppointment(new Appointment("A", t, "Same time A"));

        Appointment next = service.getNextAppointment(now);
        assertEquals("A", next.appointmentId());
    }

    @Test
    public void testGetAppointmentsInRangeSorted() {
        Instant base = Instant.now().plusSeconds(120);
        Instant t1 = base;
        Instant t2 = base.plusSeconds(60);
        Instant t3 = base.plusSeconds(120);

        service.addAppointment(new Appointment("C", t2, "middle"));
        service.addAppointment(new Appointment("A", t1, "first"));
        service.addAppointment(new Appointment("B", t3, "last"));

        List<Appointment> results = service.getAppointmentsInRange(t1, t3.plusSeconds(1));

        assertEquals(3, results.size());
        assertEquals("A", results.get(0).appointmentId());
        assertEquals("C", results.get(1).appointmentId());
        assertEquals("B", results.get(2).appointmentId());
    }

    @Test
    public void testRescheduleUpdatesIndex() {
        Instant now = Instant.now();
        Instant base = now.plusSeconds(120);
        Instant t1 = base;                 // B at now+120
        Instant t2 = base.plusSeconds(300);

        service.addAppointment(new Appointment("A", t2, "Later"));
        service.addAppointment(new Appointment("B", t1, "Sooner"));

        // Reschedule A earlier than B
        service.rescheduleAppointment("A", base.minusSeconds(30)); // now+90

        Appointment next = service.getNextAppointment(now);
        assertEquals("A", next.appointmentId());
    }


    @Test
    public void testGetAllAppointmentsSorted() {
        Instant base = Instant.now().plusSeconds(120);
        Instant t1 = base;
        Instant t2 = base.plusSeconds(60);

        service.addAppointment(new Appointment("B", t2, "2"));
        service.addAppointment(new Appointment("A", t1, "1"));
        service.addAppointment(new Appointment("C", t2, "2b"));

        List<Appointment> sorted = service.getAllAppointmentsSorted();
        assertEquals(3, sorted.size());

        // Final check on default sorting; Time first, then ID as a fallback tie-breaker
        assertEquals("A", sorted.get(0).appointmentId());
        assertEquals("B", sorted.get(1).appointmentId());
        assertEquals("C", sorted.get(2).appointmentId());
    }
}
