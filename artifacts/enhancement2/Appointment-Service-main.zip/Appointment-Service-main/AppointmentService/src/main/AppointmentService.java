package main;
// Giogioanni Morales

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.NavigableSet;
import java.util.Objects;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * AppointmentService: in-memory management of appointments.
 *
 * Primary store:
 *  - HashMap<String, Appointment> for O(1) average-time access by appointmentId.
 *
 * Secondary index Algorithms & Data Structures enhancement:
 *  - TreeMap<Instant, NavigableSet<String>> to support efficient date-based queries:
 *      - getNextAppointment(...) in O(log n)
 *      - getAppointmentsInRange(...) in O(log n + k)
 *      - getAllAppointmentsSorted() in O(n)
 *
 */
public class AppointmentService {

    // In-memory storage for appointments (ID -> Appointment).
    private final Map<String, Appointment> appointments = new HashMap<>();

    // Date index: appointmentDate -> sorted set of IDs at that exact time (stable/deterministic order).
    private final NavigableMap<Instant, NavigableSet<String>> dateIndex = new TreeMap<>();

    /**
     * Adds a new appointment. Appointment IDs must be unique.
     *
     * @param appointment the appointment to add
     * @throws IllegalArgumentException        if appointment is null
     * @throws DuplicateAppointmentIdException if the ID already exists
     */
    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null.");
        }

        String id = appointment.appointmentId();
        if (appointments.containsKey(id)) {
            throw new DuplicateAppointmentIdException("Appointment ID already exists: " + id);
        }

        appointments.put(id, appointment);
        indexAdd(appointment);
    }

    /**
     * Deletes an appointment by ID.
     *
     * @param appointmentId the appointment ID
     * @throws IllegalArgumentException     if appointmentId is null/blank
     * @throws AppointmentNotFoundException if the ID does not exist
     */
    public void deleteAppointment(String appointmentId) {
        if (appointmentId == null || appointmentId.isBlank()) {
            throw new IllegalArgumentException("Appointment ID cannot be null/blank.");
        }

        Appointment removed = appointments.remove(appointmentId);
        if (removed == null) {
            throw new AppointmentNotFoundException("Appointment ID does not exist: " + appointmentId);
        }

        indexRemove(removed);
    }

    /**
     * Retrieves an appointment by ID.
     *
     * @param appointmentId the appointment ID
     * @return the appointment
     * @throws IllegalArgumentException     if appointmentId is null/blank
     * @throws AppointmentNotFoundException if the ID does not exist
     */
    public Appointment getAppointment(String appointmentId) {
        if (appointmentId == null || appointmentId.isBlank()) {
            throw new IllegalArgumentException("Appointment ID cannot be null/blank.");
        }

        Appointment appt = appointments.get(appointmentId);
        if (appt == null) {
            throw new AppointmentNotFoundException("Appointment ID does not exist: " + appointmentId);
        }

        return appt;
    }

    /**
     * Algorithms/DS enhancement: Returns the next appointment on or after the given time.
     * If multiple appointments share the same timestamp, the appointment with the smallest ID is returned.
     *
     * @param fromInclusive starting time
     * @return next appointment
     * @throws IllegalArgumentException     if fromInclusive is null
     * @throws AppointmentNotFoundException if there are no appointments on/after fromInclusive
     */
    public Appointment getNextAppointment(Instant fromInclusive) {
        Objects.requireNonNull(fromInclusive, "fromInclusive cannot be null.");

        var entry = dateIndex.ceilingEntry(fromInclusive);
        if (entry == null) {
            throw new AppointmentNotFoundException("No upcoming appointments found.");
        }

        String id = entry.getValue().first();
        return appointments.get(id);
    }

    /**
     * Algorithms/DS enhancement: Returns appointments with dates in [startInclusive, endExclusive),
     * sorted by date ascending, then by ID ascending.
     *
     * @param startInclusive range start (inclusive)
     * @param endExclusive   range end (exclusive)
     * @return list of matching appointments
     * @throws IllegalArgumentException if either arg is null or endExclusive is not after startInclusive
     */
    public List<Appointment> getAppointmentsInRange(Instant startInclusive, Instant endExclusive) {
        if (startInclusive == null || endExclusive == null) {
            throw new IllegalArgumentException("Range endpoints cannot be null.");
        }
        if (!endExclusive.isAfter(startInclusive)) {
            throw new IllegalArgumentException("endExclusive must be after startInclusive.");
        }

        List<Appointment> results = new ArrayList<>();
        NavigableMap<Instant, NavigableSet<String>> sub =
                dateIndex.subMap(startInclusive, true, endExclusive, false);

        for (var entry : sub.entrySet()) {
            for (String id : entry.getValue()) {
                Appointment appt = appointments.get(id);
                if (appt != null) { // defensive: should always be non-null
                    results.add(appt);
                }
            }
        }

        return results;
    }

    /**
     * Algorithms/DS enhancement: Returns all appointments sorted by date ascending, then ID ascending.
     *
     * @return sorted list of all appointments
     */
    public List<Appointment> getAllAppointmentsSorted() {
        List<Appointment> results = new ArrayList<>(appointments.size());

        // This MUST iterate over dateIndex.entrySet() to maintain order!
        for (var entry : dateIndex.entrySet()) {
            for (String id : entry.getValue()) {
                Appointment appt = appointments.get(id);
                if (appt != null) {
                    results.add(appt);
                }
            }
        }
        return results;
    }

    /**
     * Algorithms/DS enhancement: Reschedules an existing appointment to a new future date.
     * Creates a new Appointment record (immutability) and updates the date index efficiently.
     *
     * @param appointmentId the appointment to reschedule
     * @param newDate       new date/time (must be in the future)
     * @return the updated appointment
     * @throws IllegalArgumentException     if appointmentId is null/blank or if newDate is null
     * @throws AppointmentNotFoundException if the appointment does not exist
     */
    public Appointment rescheduleAppointment(String appointmentId, Instant newDate) {
        // 1. Validation
        if (appointmentId == null || appointmentId.isBlank()) {
            throw new IllegalArgumentException("ID cannot be null.");
        }
        Objects.requireNonNull(newDate, "Date cannot be null.");

        Appointment existing = appointments.get(appointmentId);
        if (existing == null) {
            throw new AppointmentNotFoundException("Not found: " + appointmentId);
        }

        // REMOVE the old index entry using the OLD date
        indexRemove(existing);

        // Create the new immutable record
        Appointment updated = new Appointment(existing.appointmentId(), newDate, existing.description());

        // Update the main store
        appointments.put(appointmentId, updated);

        // ADD the new index entry using the NEW date
        indexAdd(updated);

        return updated;
    }

    // ---- Index helpers ----
    private void indexAdd(Appointment appointment) {
        dateIndex.computeIfAbsent(appointment.appointmentDate(), k -> new TreeSet<>())
                .add(appointment.appointmentId());
    }

    private void indexRemove(Appointment appointment) {
        NavigableSet<String> ids = dateIndex.get(appointment.appointmentDate());
        if (ids != null) {
            ids.remove(appointment.appointmentId());
            // Clean up the map entry if no more appointments exist at this exact microsecond
            if (ids.isEmpty()) {
                dateIndex.remove(appointment.appointmentDate());
            }
        }
    }
}
