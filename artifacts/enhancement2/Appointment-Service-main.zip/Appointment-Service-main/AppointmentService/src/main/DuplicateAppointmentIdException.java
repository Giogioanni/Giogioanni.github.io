package main;

// Thrown when attempting to add an appointment whose ID already exists.
public class DuplicateAppointmentIdException extends RuntimeException {
    public DuplicateAppointmentIdException(String message) {
        super(message);
    }
}
