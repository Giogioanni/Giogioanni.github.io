package main;
//Giogioanni Morales
/**
 * This is thrown when attempting to access or delete an appointment ID that does not exist.
 */
public class AppointmentNotFoundException extends IllegalArgumentException {
    public AppointmentNotFoundException(String message) {
        super(message);
    }
}