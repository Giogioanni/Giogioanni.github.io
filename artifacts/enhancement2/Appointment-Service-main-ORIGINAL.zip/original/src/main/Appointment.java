package main;
// Giogioanni Morales
import java.util.Date; // for the appointmentDate field 

/**
 * appointmentId storage of appointment details
 */
public record Appointment(String appointmentId, Date appointmentDate, String description) {
    //constructor for appointment object
    public Appointment { //  All of these test cases must not be null
        // must be more than 10 characters
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("invalid appointment ID");
        }
        // must not be in the past
        if (appointmentDate == null || appointmentDate.before(new Date())) { // (new Date()) to check if the date is in the past.
            throw new IllegalArgumentException("invalid appointment date");
        }
        // must not exceed 50 characters
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("invalid description");
        }
    }
}
