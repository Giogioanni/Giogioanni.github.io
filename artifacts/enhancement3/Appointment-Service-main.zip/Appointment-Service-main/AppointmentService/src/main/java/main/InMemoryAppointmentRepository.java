package main;
// Giogioanni Morales

import java.time.Instant;
import java.util.*;

/**
 * In-memory implementation of AppointmentRepository.
 * Uses:
 *  - HashMap for fast ID lookup (O(1) avg)
 *  - TreeMap + TreeSet for efficient date queries (O(log n))
 */
public class InMemoryAppointmentRepository implements AppointmentRepository {

    private final Map<String, Appointment> appointments = new HashMap<>();
    private final NavigableMap<Instant, NavigableSet<String>> dateIndex = new TreeMap<>();

    @Override
    public void save(Appointment appointment) {
        Objects.requireNonNull(appointment, "Appointment cannot be null.");
        String id = appointment.appointmentId();
        if (appointments.containsKey(id)) {
            throw new DuplicateAppointmentIdException("Appointment ID already exists: " + id);
        }
        appointments.put(id, appointment);
        indexAdd(appointment);
    }

    @Override
    public Optional<Appointment> findById(String appointmentId) {
        if (appointmentId == null || appointmentId.isBlank()) {
            throw new IllegalArgumentException("Appointment ID cannot be null/blank.");
        }
        return Optional.ofNullable(appointments.get(appointmentId));
    }

    @Override
    public boolean deleteById(String appointmentId) {
        if (appointmentId == null || appointmentId.isBlank()) {
            throw new IllegalArgumentException("Appointment ID cannot be null/blank.");
        }
        Appointment removed = appointments.remove(appointmentId);
        if (removed == null) return false;
        indexRemove(removed);
        return true;
    }

    @Override
    public void update(Appointment appointment) {
        Objects.requireNonNull(appointment, "Appointment cannot be null.");
        String id = appointment.appointmentId();
        Appointment existing = appointments.get(id);
        if (existing == null) {
            throw new AppointmentNotFoundException("Appointment ID does not exist: " + id);
        }
        // remove old index entry, replace, add new index entry
        indexRemove(existing);
        appointments.put(id, appointment);
        indexAdd(appointment);
    }

    @Override
    public Optional<Appointment> findNext(Instant fromInclusive) {
        if (fromInclusive == null) {
            throw new IllegalArgumentException("fromInclusive cannot be null.");
        }
        Map.Entry<Instant, NavigableSet<String>> entry = dateIndex.ceilingEntry(fromInclusive);
        if (entry == null) return Optional.empty();
        String id = entry.getValue().first(); // deterministic
        return Optional.ofNullable(appointments.get(id));
    }

    @Override
    public List<Appointment> findInRange(Instant startInclusive, Instant endExclusive) {
        if (startInclusive == null || endExclusive == null) {
            throw new IllegalArgumentException("Range endpoints cannot be null.");
        }
        if (!endExclusive.isAfter(startInclusive)) {
            throw new IllegalArgumentException("endExclusive must be after startInclusive.");
        }

        List<Appointment> results = new ArrayList<>();
        NavigableMap<Instant, NavigableSet<String>> sub = dateIndex.subMap(startInclusive, true, endExclusive, false);
        for (Map.Entry<Instant, NavigableSet<String>> e : sub.entrySet()) {
            for (String id : e.getValue()) {
                Appointment appt = appointments.get(id);
                if (appt != null) results.add(appt);
            }
        }
        return results;
    }

    @Override
    public List<Appointment> findAllSorted() {
        List<Appointment> results = new ArrayList<>();
        for (Map.Entry<Instant, NavigableSet<String>> e : dateIndex.entrySet()) {
            for (String id : e.getValue()) {
                Appointment appt = appointments.get(id);
                if (appt != null) results.add(appt);
            }
        }
        return results;
    }

    private void indexAdd(Appointment appointment) {
        dateIndex.computeIfAbsent(appointment.appointmentDate(), k -> new TreeSet<>())
                .add(appointment.appointmentId());
    }

    private void indexRemove(Appointment appointment) {
        NavigableSet<String> ids = dateIndex.get(appointment.appointmentDate());
        if (ids == null) return;
        ids.remove(appointment.appointmentId());
        if (ids.isEmpty()) dateIndex.remove(appointment.appointmentDate());
    }
}
