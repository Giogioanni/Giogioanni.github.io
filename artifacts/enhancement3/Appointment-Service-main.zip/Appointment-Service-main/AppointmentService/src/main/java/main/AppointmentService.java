package main;
// Giogioanni Morales

import java.time.Instant;
import java.util.List;
import java.util.Objects;

/**
 * AppointmentService: business-logic layer for appointments.
 *
 * Database enhancement (Milestone Four):
 * - Service delegates persistence to an AppointmentRepository.
 * - Default implementation remains in-memory (for easy unit testing),
 *   but a SQLiteAppointmentRepository is included for real persistence via JDBC.
 */
public class AppointmentService {

    private final AppointmentRepository repository;

    /** Default constructor uses in-memory repository. */
    public AppointmentService() {
        this.repository = new InMemoryAppointmentRepository();
    }

    /** Dependency injection constructor for swapping persistence implementations. */
    public AppointmentService(AppointmentRepository repository) {
        this.repository = Objects.requireNonNull(repository, "repository cannot be null");
    }

    /** Adds a new appointment (ID must be unique). */
    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null.");
        }
        repository.save(appointment);
    }

    /** Deletes an appointment by ID. */
    public void deleteAppointment(String appointmentId) {
        if (appointmentId == null || appointmentId.isBlank()) {
            throw new IllegalArgumentException("Appointment ID cannot be null/blank.");
        }
        boolean deleted = repository.deleteById(appointmentId);
        if (!deleted) {
            throw new AppointmentNotFoundException("Appointment ID does not exist: " + appointmentId);
        }
    }

    /** Retrieves an appointment by ID. */
    public Appointment getAppointment(String appointmentId) {
        if (appointmentId == null || appointmentId.isBlank()) {
            throw new IllegalArgumentException("Appointment ID cannot be null/blank.");
        }
        return repository.findById(appointmentId)
                .orElseThrow(() -> new AppointmentNotFoundException("Appointment ID does not exist: " + appointmentId));
    }

    /** Returns the next appointment at/after fromInclusive. */
    public Appointment getNextAppointment(Instant fromInclusive) {
        if (fromInclusive == null) {
            throw new IllegalArgumentException("fromInclusive cannot be null.");
        }
        return repository.findNext(fromInclusive)
                .orElseThrow(() -> new AppointmentNotFoundException("No appointment found at/after: " + fromInclusive));
    }

    /** Returns appointments in [startInclusive, endExclusive). */
    public List<Appointment> getAppointmentsInRange(Instant startInclusive, Instant endExclusive) {
        return repository.findInRange(startInclusive, endExclusive);
    }

    /** Returns all appointments sorted by date then ID. */
    public List<Appointment> getAllAppointmentsSorted() {
        return repository.findAllSorted();
    }

    /** Reschedule an existing appointment to a new date (keeps description). */
    public void rescheduleAppointment(String appointmentId, Instant newDate) {
        if (appointmentId == null || appointmentId.isBlank()) {
            throw new IllegalArgumentException("Appointment ID cannot be null/blank.");
        }
        if (newDate == null) {
            throw new IllegalArgumentException("newDate cannot be null.");
        }

        Appointment existing = getAppointment(appointmentId);
        Appointment updated = new Appointment(existing.appointmentId(), newDate, existing.description());
        repository.update(updated);
    }
}
