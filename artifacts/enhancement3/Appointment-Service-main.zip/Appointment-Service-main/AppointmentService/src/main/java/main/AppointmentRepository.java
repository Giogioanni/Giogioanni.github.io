package main;
// Giogioanni Morales

import java.time.Instant;
import java.util.List;
import java.util.Optional;

/**
 * AppointmentRepository abstracts persistence for appointments.
 * This supports both in-memory and database-backed implementations.
 */
public interface AppointmentRepository {

    /**
     * Save a new appointment.
     * @throws DuplicateAppointmentIdException if an appointment with the same ID already exists
     */
    void save(Appointment appointment);

    /** Find an appointment by ID. */
    Optional<Appointment> findById(String appointmentId);

    /** Delete by ID. @return true if deleted, false if not found */
    boolean deleteById(String appointmentId);

    /** Update an existing appointment. @throws AppointmentNotFoundException if not found */
    void update(Appointment appointment);

    /** Get the next appointment at/after the given instant. */
    Optional<Appointment> findNext(Instant fromInclusive);

    /** Get appointments in [startInclusive, endExclusive), sorted by date then ID. */
    List<Appointment> findInRange(Instant startInclusive, Instant endExclusive);

    /** Get all appointments sorted by date then ID. */
    List<Appointment> findAllSorted();
}
