package main;
// Giogioanni Morales

import java.time.Instant;

/**
 * Optional demo runner for the SQLite repository. (I am using DB browser for SQLite)
 * This is not required for unit tests, but this helps me demonstrate persistence.
 */
public class DemoMain {
    public static void main(String[] args) {
        String url = "jdbc:sqlite:appointments.db";
        AppointmentRepository repo = new SQLiteAppointmentRepository(url);
        AppointmentService service = new AppointmentService(repo);

        Appointment a1 = new Appointment("A123", Instant.now().plusSeconds(3600), "Dentist");
        service.addAppointment(a1);

        System.out.println("Saved: " + service.getAppointment("A123"));
        System.out.println("All sorted: " + service.getAllAppointmentsSorted());
    }
}
