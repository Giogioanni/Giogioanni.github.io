package main;
// Giogioanni Morales

import java.sql.*;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * SQLite-backed AppointmentRepository using JDBC.
 *
 * Notes:
 * - Requires the SQLite JDBC driver on the classpath (e.g., org.xerial:sqlite-jdbc).
 * - Uses prepared statements to prevent SQL injection.
 * - Enforces constraints at both application level (Appointment validation) and DB schema.
 */
public class SQLiteAppointmentRepository implements AppointmentRepository {

    private final String jdbcUrl;

    public SQLiteAppointmentRepository(String jdbcUrl) {
        if (jdbcUrl == null || jdbcUrl.isBlank()) {
            throw new IllegalArgumentException("jdbcUrl cannot be null/blank.");
        }
        this.jdbcUrl = jdbcUrl;
        initSchema();
    }

    private Connection connect() throws SQLException {
        return DriverManager.getConnection(jdbcUrl);
    }

    private void initSchema() {
        String createTable = """ 
            CREATE TABLE IF NOT EXISTS appointments (
                id TEXT PRIMARY KEY,
                date_millis INTEGER NOT NULL,
                description TEXT NOT NULL,
                CHECK (length(id) <= 10),
                CHECK (length(description) <= 50)
            );
            """;

        String createIndex = "CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(date_millis);";

        try (Connection c = connect(); Statement st = c.createStatement()) {
            st.execute(createTable);
            st.execute(createIndex);
        } catch (SQLException e) {
            throw new RuntimeException("Failed to initialize database schema.", e);
        }
    }

    @Override
    public void save(Appointment appointment) {
        if (appointment == null) throw new IllegalArgumentException("Appointment cannot be null.");
        String sql = "INSERT INTO appointments (id, date_millis, description) VALUES (?, ?, ?);";
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, appointment.appointmentId());
            ps.setLong(2, appointment.appointmentDate().toEpochMilli());
            ps.setString(3, appointment.description());
            ps.executeUpdate();
        } catch (SQLException e) {
            // SQLite uses constraint failures for duplicate PK
            if (isConstraintViolation(e)) {
                throw new DuplicateAppointmentIdException("Appointment ID already exists: " + appointment.appointmentId());
            }
            throw new RuntimeException("Failed to save appointment.", e);
        }
    }

    @Override
    public Optional<Appointment> findById(String appointmentId) {
        if (appointmentId == null || appointmentId.isBlank()) {
            throw new IllegalArgumentException("Appointment ID cannot be null/blank.");
        }
        String sql = "SELECT id, date_millis, description FROM appointments WHERE id = ?;";
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, appointmentId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return Optional.empty();
                return Optional.of(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to fetch appointment.", e);
        }
    }

    @Override
    public boolean deleteById(String appointmentId) {
        if (appointmentId == null || appointmentId.isBlank()) {
            throw new IllegalArgumentException("Appointment ID cannot be null/blank.");
        }
        String sql = "DELETE FROM appointments WHERE id = ?;";
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, appointmentId);
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to delete appointment.", e);
        }
    }

    @Override
    public void update(Appointment appointment) {
        if (appointment == null) throw new IllegalArgumentException("Appointment cannot be null.");
        String sql = "UPDATE appointments SET date_millis = ?, description = ? WHERE id = ?;";
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, appointment.appointmentDate().toEpochMilli());
            ps.setString(2, appointment.description());
            ps.setString(3, appointment.appointmentId());
            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new AppointmentNotFoundException("Appointment ID does not exist: " + appointment.appointmentId());
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to update appointment.", e);
        }
    }

    @Override
    public Optional<Appointment> findNext(Instant fromInclusive) {
        if (fromInclusive == null) throw new IllegalArgumentException("fromInclusive cannot be null.");
        String sql = """ 
            SELECT id, date_millis, description
            FROM appointments
            WHERE date_millis >= ?
            ORDER BY date_millis ASC, id ASC
            LIMIT 1;
            """;

        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, fromInclusive.toEpochMilli());
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return Optional.empty();
                return Optional.of(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to query next appointment.", e);
        }
    }

    @Override
    public List<Appointment> findInRange(Instant startInclusive, Instant endExclusive) {
        if (startInclusive == null || endExclusive == null) {
            throw new IllegalArgumentException("Range endpoints cannot be null.");
        }
        if (!endExclusive.isAfter(startInclusive)) {
            throw new IllegalArgumentException("endExclusive must be after startInclusive.");
        }

        String sql = """ 
            SELECT id, date_millis, description
            FROM appointments
            WHERE date_millis >= ? AND date_millis < ?
            ORDER BY date_millis ASC, id ASC;
            """;

        List<Appointment> results = new ArrayList<>();
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, startInclusive.toEpochMilli());
            ps.setLong(2, endExclusive.toEpochMilli());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(mapRow(rs));
                }
            }
            return results;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to query appointments in range.", e);
        }
    }

    @Override
    public List<Appointment> findAllSorted() {
        String sql = """ 
            SELECT id, date_millis, description
            FROM appointments
            ORDER BY date_millis ASC, id ASC;
            """;

        List<Appointment> results = new ArrayList<>();
        try (Connection c = connect();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                results.add(mapRow(rs));
            }
            return results;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to query all appointments.", e);
        }
    }

    private Appointment mapRow(ResultSet rs) throws SQLException {
        String id = rs.getString("id");
        long millis = rs.getLong("date_millis");
        String description = rs.getString("description");
        return new Appointment(id, Instant.ofEpochMilli(millis), description);
    }

    private boolean isConstraintViolation(SQLException e) {
        // SQLite constraint errors often have error code 19.
        return e.getErrorCode() == 19 || (e.getMessage() != null && e.getMessage().toLowerCase().contains("constraint"));
    }
}
