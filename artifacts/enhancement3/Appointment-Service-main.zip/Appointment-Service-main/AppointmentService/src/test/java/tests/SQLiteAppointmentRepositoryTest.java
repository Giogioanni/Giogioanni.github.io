package tests;
// Giogioanni Morales

import main.Appointment;
import main.SQLiteAppointmentRepository;
import main.AppointmentRepository;
import main.AppointmentService;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assumptions;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;

import static org.junit.jupiter.api.Assertions.*;

/**
 * SQLite integration test for Milestone Four.
 *
 * This test will be skipped automatically if the SQLite JDBC driver is not present
 * (ClassNotFoundException for org.sqlite.JDBC).
 */
public class SQLiteAppointmentRepositoryTest {

    private static boolean sqliteDriverPresent() {
        try {
            Class.forName("org.sqlite.JDBC");
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    @Test
    public void testSaveAndFindById() throws Exception {
        Assumptions.assumeTrue(sqliteDriverPresent(), "SQLite JDBC driver not on classpath; skipping.");

        Path dbFile = Files.createTempFile("appointments-test", ".db");
        dbFile.toFile().deleteOnExit();

        String url = "jdbc:sqlite:" + dbFile.toAbsolutePath();
        AppointmentRepository repo = new SQLiteAppointmentRepository(url);
        AppointmentService service = new AppointmentService(repo);

        Appointment appt = new Appointment("DB1", Instant.now().plusSeconds(3600), "DB Test");
        service.addAppointment(appt);

        Appointment loaded = service.getAppointment("DB1");
        assertEquals("DB1", loaded.appointmentId());
        assertEquals("DB Test", loaded.description());
    }
}
