# Appointment Service (Algorithms & Data Structures Enhancement)

This enhanced version builds on the Software Design & Engineering improvements (Milestone Two) and adds an Algorithms & Data Structures enhancement:

- Primary store: `HashMap<String, Appointment>` for fast ID-based access.
- Secondary index: `TreeMap<Instant, Set<String>>` for efficient date-based queries:
    - `getNextAppointment(fromInclusive)`
    - `getAppointmentsInRange(startInclusive, endExclusive)`
    - `getAllAppointmentsSorted()`
    - `rescheduleAppointment(id, newDate)`

## How to run tests (JUnit 5)
Run `AppointmentTest` and `AppointmentServiceTest` from your IDE test runner.

## Folder layout
- `src/main`: production code
- `src/tests`: unit tests