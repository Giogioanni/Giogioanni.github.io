package tests;
// Giogioanni Morales

import static org.junit.jupiter.api.Assertions.*;

import java.time.Instant;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import main.Appointment;
import main.AppointmentNotFoundException;
import main.AppointmentService;
import main.DuplicateAppointmentIdException;

public class AppointmentServiceTest {

    private AppointmentService appointmentService;

    @BeforeEach
    public void setUp() {
        appointmentService = new AppointmentService();
    }

    @Test
    public void testAddAppointment() {
        Instant futureInstant = Instant.now().plusSeconds(60);
        Appointment appointment = new Appointment("9876543210", futureInstant, "Valid description");

        appointmentService.addAppointment(appointment);

        assertEquals(appointment, appointmentService.getAppointment("9876543210"));
    }

    @Test
    public void testAddDuplicateAppointment() {
        Instant futureInstant = Instant.now().plusSeconds(60);
        Appointment appointment1 = new Appointment("1234567890", futureInstant, "Valid description");
        Appointment appointment2 = new Appointment("1234567890", futureInstant, "Another description");

        appointmentService.addAppointment(appointment1);

        assertThrows(DuplicateAppointmentIdException.class, () -> appointmentService.addAppointment(appointment2));
    }

    @Test
    public void testDeleteAppointment() {
        Instant futureInstant = Instant.now().plusSeconds(60);
        Appointment appointment = new Appointment("1234567890", futureInstant, "Valid description");

        appointmentService.addAppointment(appointment);
        appointmentService.deleteAppointment("1234567890");

        assertThrows(AppointmentNotFoundException.class, () -> appointmentService.getAppointment("1234567890"));
    }

    @Test
    public void testGetNonexistentAppointmentThrows() {
        assertThrows(AppointmentNotFoundException.class, () -> appointmentService.getAppointment("nonexistent"));
    }

    @Test
    public void testDeleteNonexistentAppointmentThrows() {
        assertThrows(AppointmentNotFoundException.class, () -> appointmentService.deleteAppointment("nonexistent"));
    }

    @Test
    public void testDeleteThenReAddSameId() {
        Instant futureInstant = Instant.now().plusSeconds(60);
        Appointment first = new Appointment("A123456789", futureInstant, "First");
        appointmentService.addAppointment(first);
        appointmentService.deleteAppointment("A123456789");

        Appointment second = new Appointment("A123456789", futureInstant, "Second");
        appointmentService.addAppointment(second);

        assertEquals("Second", appointmentService.getAppointment("A123456789").description());
    }

    @Test
    public void testAddNullAppointmentThrows() {
        assertThrows(IllegalArgumentException.class, () -> appointmentService.addAppointment(null));
    }
}
