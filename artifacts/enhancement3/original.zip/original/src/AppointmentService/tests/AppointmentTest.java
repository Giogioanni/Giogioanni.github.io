package tests;
// Giogioanni Morales

import static org.junit.jupiter.api.Assertions.*;

import java.time.Instant;

import org.junit.jupiter.api.Test;

import main.Appointment;
import main.InvalidAppointmentException;

public class AppointmentTest {

    @Test
    public void testValidAppointment() {
        Instant futureInstant = Instant.now().plusSeconds(60); // 60 seconds in the future
        Appointment appointment = new Appointment("987654321", futureInstant, "Valid description");

        assertNotNull(appointment);
        assertEquals("987654321", appointment.appointmentId());
        assertEquals(futureInstant, appointment.appointmentDate());
        assertEquals("Valid description", appointment.description());
    }

    @Test
    public void testAppointmentIdBoundaryValid10Chars() {
        Instant futureInstant = Instant.now().plusSeconds(60);
        Appointment appointment = new Appointment("1234567890", futureInstant, "Valid description");
        assertEquals("1234567890", appointment.appointmentId());
    }

    @Test
    public void testDescriptionBoundaryValid50Chars() {
        Instant futureInstant = Instant.now().plusSeconds(60);
        String desc50 = "12345678901234567890123456789012345678901234567890"; // 50 chars
        Appointment appointment = new Appointment("1234567890", futureInstant, desc50);
        assertEquals(50, appointment.description().length());
    }

    @Test
    public void testInvalidAppointmentId() {
        Instant futureInstant = Instant.now().plusSeconds(60);

        assertThrows(InvalidAppointmentException.class, () -> new Appointment(null, futureInstant, "Valid description"));
        assertThrows(InvalidAppointmentException.class, () -> new Appointment("   ", futureInstant, "Valid description"));
        assertThrows(InvalidAppointmentException.class, () -> new Appointment("12345678910", futureInstant, "Valid description")); // 11 chars
    }

    @Test
    public void testInvalidAppointmentDate() {
        Instant pastInstant = Instant.now().minusSeconds(60);

        assertThrows(InvalidAppointmentException.class, () -> new Appointment("1234567890", pastInstant, "Valid description"));
        assertThrows(InvalidAppointmentException.class, () -> new Appointment("1234567890", null, "Valid description"));
    }

    @Test
    public void testInvalidDescription() {
        Instant futureInstant = Instant.now().plusSeconds(60);

        assertThrows(InvalidAppointmentException.class, () -> new Appointment("1234567890", futureInstant, null));
        assertThrows(InvalidAppointmentException.class, () ->
                new Appointment("1234567890", futureInstant, "This description is way more than fifty characters long and is thus invalid "));
    }
}
