package main;

/**
 * Thrown when an Appointment fails validation rules.
 */
public class InvalidAppointmentException extends IllegalArgumentException {
    public InvalidAppointmentException(String message) {
        super(message);
    }
}
