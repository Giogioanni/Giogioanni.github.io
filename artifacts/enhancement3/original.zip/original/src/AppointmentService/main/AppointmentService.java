package main;
// Giogioanni Morales

import java.util.HashMap;
import java.util.Map;

/**
 * AppointmentService: in-memory management of appointments keyed by appointmentId.
 *
 * Supported operations:
 * - addAppointment: adds a new appointment (rejects duplicate IDs)
 * - deleteAppointment: deletes by ID (throws if missing)
 * - getAppointment: retrieves by ID (throws if missing)
 */
public class AppointmentService {

    // In-memory storage for appointments (ID -> Appointment).
    private final Map<String, Appointment> appointments = new HashMap<>();

    /**
     * Adds a new appointment. Appointment IDs must be unique.
     *
     * @param appointment the appointment to add
     * @throws IllegalArgumentException if appointment is null
     * @throws DuplicateAppointmentIdException if the ID already exists
     */
    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null.");
        }

        String id = appointment.appointmentId();
        if (appointments.containsKey(id)) {
            throw new DuplicateAppointmentIdException("Appointment ID already exists: " + id);
        }

        appointments.put(id, appointment);
    }

    /**
     * Deletes an appointment by its ID.
     *
     * @param appointmentId the ID of the appointment to delete
     * @throws IllegalArgumentException if appointmentId is null/blank
     * @throws AppointmentNotFoundException if the ID does not exist
     */
    public void deleteAppointment(String appointmentId) {
        if (appointmentId == null || appointmentId.isBlank()) {
            throw new IllegalArgumentException("Appointment ID cannot be null/blank.");
        }

        if (!appointments.containsKey(appointmentId)) {
            throw new AppointmentNotFoundException("Appointment ID does not exist: " + appointmentId);
        }

        appointments.remove(appointmentId);
    }

    /**
     * Retrieves an appointment by its ID.
     *
     * @param appointmentId the ID to look up
     * @return the Appointment
     * @throws IllegalArgumentException if appointmentId is null/blank
     * @throws AppointmentNotFoundException if the ID does not exist
     */
    public Appointment getAppointment(String appointmentId) {
        if (appointmentId == null || appointmentId.isBlank()) {
            throw new IllegalArgumentException("Appointment ID cannot be null/blank.");
        }

        Appointment appt = appointments.get(appointmentId);
        if (appt == null) {
            throw new AppointmentNotFoundException("Appointment ID does not exist: " + appointmentId);
        }

        return appt;
    }
}
