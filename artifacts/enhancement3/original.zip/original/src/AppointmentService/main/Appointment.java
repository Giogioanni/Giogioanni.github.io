package main;
// Giogioanni Morales

import java.time.Instant;

/**
 * Appointment record: stores appointment details and enforces validation rules.
 *
 * Rules:
 * - appointmentId: required, non-blank, max 10 characters
 * - appointmentDate: required, must be strictly in the future
 * - description: required, max 50 characters
 */
public record Appointment(String appointmentId, Instant appointmentDate, String description) {

    // Compact constructor validates inputs to keep the object always in a valid state.
    public Appointment {
        if (appointmentId == null || appointmentId.isBlank() || appointmentId.length() > 10) {
            throw new InvalidAppointmentException("Appointment ID must be 1-10 characters and non-blank.");
        }

        if (appointmentDate == null || !appointmentDate.isAfter(Instant.now())) {
            throw new InvalidAppointmentException("Appointment date must be in the future.");
        }

        if (description == null || description.length() > 50) {
            throw new InvalidAppointmentException("Description must be 0-50 characters (non-null).");
        }
    }
}
