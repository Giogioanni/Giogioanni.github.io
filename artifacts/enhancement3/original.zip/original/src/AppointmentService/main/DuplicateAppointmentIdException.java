package main;

/**
 * Thrown when attempting to add an appointment with an ID that already exists.
 */
public class DuplicateAppointmentIdException extends IllegalArgumentException {
    public DuplicateAppointmentIdException(String message) {
        super(message);
    }
}
