# CS499 - Appointment Service (Milestone Two: Software Design & Engineering)

This submission contains **original** and **enhanced** versions of the Appointment Service artifact.

## What's included
- `original/` - baseline artifact (as reviewed in Milestone One)
- `enhanced/` - Milestone Two enhancements (Software Design & Engineering)

## How to run (recommended)
1. Open the project in IntelliJ IDEA.
2. Ensure JUnit 5 is available (IntelliJ will usually detect it automatically).
3. Run:
   - `AppointmentTest`
   - `AppointmentServiceTest`

## Milestone Two enhancements (high level)
- Improved robustness by replacing mutable `java.util.Date` with immutable `java.time.Instant` in `Appointment`.
- Added clearer exception types:
  - `InvalidAppointmentException`
  - `DuplicateAppointmentIdException`
  - `AppointmentNotFoundException`
- Strengthened input validation in `AppointmentService` (null/blank checks).
- Expanded unit tests with boundary cases and additional service behaviors.
- Added repo hygiene guidance via `.gitignore` to avoid committing build outputs.
